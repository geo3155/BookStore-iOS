//
//  LoginButton.swift
//  BookStore
//
//  Created by George Predan on 02.12.2022.
//

import SwiftUI

struct LoginButton: View {
   
    let title: String
    let action: () -> Void
    
    var body: some View {
        Button {
            action()
        } label: {
            RoundedRectangle(cornerRadius: 28.5)
                .fill(Color.neonBlue)
                .frame(width: 248, height: 60)
                .overlay {
                    Text(title)
                        .foregroundColor(.white)
                        .font(.Main.regular(size: 15))
                }
        }
        .buttonStyle(.plain)

    }
}

struct LoginButton_Previews: PreviewProvider {
    static var previews: some View {
        LoginButton(title: "Sign Up", action: {})
    }
}
