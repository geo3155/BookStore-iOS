//
//  Icons.swift
//  BookStore
//
//  Created by George Predan on 26.01.2023.
//

import SwiftUI

struct ProfileIcon: View {
    var size: CGSize = .init(width: 38, height: 38)
    var body: some View {
        Session.profilePhoto
            .resizable()
            .frame(width: size.width, height: size.height)
            .clipShape(RoundedRectangle(cornerRadius: 10))
            .shadow(radius: 2)
    }
}

struct SettingIcon: View {
    
    var width: CGFloat = 58
    var height: CGFloat = 58
    
    var body: some View {
        RoundedRectangle(cornerRadius: 14)
            .fill(.white)
            .frame(width: width, height: height)
            .shadow(radius: 2)
            .overlay {
                settingImage
            }
    }
    
    private var settingImage: some View {
        VStack(spacing: 3) {
            HStack(spacing: -1) {
                tomatoLine
                circle
                blueLine
            }
            HStack(spacing: -1) {
                blueLine
                circle
                tomatoLine
            }
        }
    }
    
    private var blueLine: some View {
        RoundedRectangle(cornerRadius: 10)
            .fill(Color.neonBlue)
            .frame(width: 10, height: 4)
    }
    private var circle: some View {
        Circle()
            .fill(Color.neonBlue)
            .frame(width: 12, height: 12)
    }
    private var tomatoLine: some View {
        RoundedRectangle(cornerRadius: 10)
            .fill(Color.tomato.opacity(0.25))
            .frame(width: 18, height: 4)
    }
}

struct ProfileIcon_Previews: PreviewProvider {
    static var previews: some View {
        SettingIcon()
    }
}
