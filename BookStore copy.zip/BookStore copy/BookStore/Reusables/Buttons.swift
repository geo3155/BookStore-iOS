//
//  BackButton.swift
//  BookStore
//
//  Created by George Predan on 12.01.2023.
//

import Foundation
import SwiftUI

struct BackButton: View {
    
    let action: () -> Void
    
    var body: some View {
        Button {
            action()
        } label: {
            RoundedRectangle(cornerRadius: 10)
                .fill(Color.maxBluePurple)
                .shadow(radius: 2)
                .overlay {
                    Image(systemName: "chevron.backward")
                        .foregroundColor(.white)
                }
                .frame(width: 38, height: 38)
        }
        .buttonStyle(.plain)

    }
}

struct MenuButton: View {
    
    let action: () -> Void
    
    var body: some View {
        Button {
            action()
        } label: {
            RoundedRectangle(cornerRadius: 10)
                .fill(Color.white)
                .shadow(radius: 2)
                .overlay {
                    menuIcon
                }
                .frame(width: 38, height: 38)
        }
        .buttonStyle(.plain)

    }
    
    private var menuIcon: some View {
        VStack(alignment: .leading, spacing: 5) {
            RoundedRectangle(cornerRadius: 10)
                .frame(width: 18, height: 3)
            RoundedRectangle(cornerRadius: 10)
                .frame(width: 13, height: 3)
        }
    }
}

struct Buttons_Previews: PreviewProvider {
    static var previews: some View {
        MenuButton(action: {})
    }
}

