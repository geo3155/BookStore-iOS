//
//  HalfCircle.swift
//  BookStore
//
//  Created by George Predan on 15.12.2022.
//

import SwiftUI

struct QuarterCircle: Shape {
    
    func path(in rect: CGRect) -> Path {
        let x = CGPoint(x: rect.midX, y: rect.midY)
        return Path { path in
            path.move(to: x)
            path.addArc(center: x, radius: rect.height / 2, startAngle: Angle(degrees: -180), endAngle: Angle(degrees: 90), clockwise: true)
        }
    }
}

struct HeaderStyle: View {
    var body: some View {
        HStack {
            Circle()
                .trim(from: 0, to: 0.5)
                .fill(Color.maxBluePurple)
                .frame(width: 165)
            Spacer()
            QuarterCircle()
                .frame(height: 165)
        }
    }
}

struct HeaderStyle_Previews: PreviewProvider {
    static var previews: some View {
        HeaderStyle()
    }
}
