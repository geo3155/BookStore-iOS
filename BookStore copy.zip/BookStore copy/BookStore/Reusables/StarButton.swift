//
//  StarButton.swift
//  BookStore
//
//  Created by George Predan on 25.02.2023.
//

import SwiftUI

struct StarButton: View {
    var body: some View {
        Image(systemName: "star.fill")
            .resizable()
            .scaledToFit()
            .frame(width: 24)
            .foregroundColor(.white)
            .padding(8)
            .background {
                Circle()
                    .fill(Color.neonBlue)
            }
    }
}

struct StarButton_Previews: PreviewProvider {
    static var previews: some View {
        StarButton()
    }
}
