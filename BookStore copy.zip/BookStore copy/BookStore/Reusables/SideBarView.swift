//
//  SideBarView.swift
//  BookStore
//
//  Created by George Predan on 09.02.2023.
//

import SwiftUI

struct SideBarView: View {
    
    @StateObject private var userRepository = UserRepository.shared
    let profileAction: () -> Void
    let myOrdersAction: () -> Void
    let settingsAction: () -> Void
    
    var body: some View {
        VStack(alignment: .leading, spacing: 30) {
            profileInfo
            options
            Spacer()
            LogOutButton {
                Session.didInstallApp = false
            }
        }
        .padding()
        //        .background(.red)
    }
    
    private var profileInfo: some View {
        VStack(alignment: .leading) {
            ProfileIcon(size: CGSize(width: 90, height: 90))
                .clipShape(Circle())
            Text(userRepository.user?.userName ?? "")
                .font(.Main.regular(size: 25))
            Text(userRepository.user?.email ?? "")
                .font(.Main.regular(size: 16))
                .foregroundColor(.gray)
        }
    }
    
    private var options: some View {
        VStack(alignment: .leading, spacing: 30) {
            option(image: Image(systemName: "doc.fill"), text: "My Orders", action: myOrdersAction)
            option(image: Image(systemName: "person.crop.circle.fill"), text: "My Profile", action: profileAction)
            
            option(image: Image(systemName: "gear"), text: "Settings", action: settingsAction)
        }
    }
    
    private func option(image: Image, text: String, action: @escaping () -> Void) -> some View {
        Button {
            action()
        } label: {
            HStack(spacing: 10) {
                image
                    .resizable()
                    .scaledToFit()
                    .frame(height: 25)
                    .foregroundColor(.gray)
                
                Text(text)
                    .font(.Main.regular(size: 20))
                    .foregroundColor(.black)
            }
        }
        .buttonStyle(.plain)
    }
}

struct SideBarView_Previews: PreviewProvider {
    static var previews: some View {
        SideBarView(profileAction: {}, myOrdersAction: {}, settingsAction: {})
    }
}
