//
//  NavigationBar.swift
//  BookStore
//
//  Created by George Predan on 21.02.2023.
//

import SwiftUI

struct NavigationBar: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct NavigationBar_Previews: PreviewProvider {
    static var previews: some View {
        NavigationBar()
    }
}
