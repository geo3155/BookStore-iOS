//
//  LocationButton.swift
//  BookStore
//
//  Created by George Predan on 01.03.2023.
//

import SwiftUI

struct LocationButton: View {
    
    let action: () -> Void
    
    var body: some View {
        Button {
            withAnimation {
                action()
            }
        } label: {
            Image(systemName: "location.fill")
                .resizable()
                .frame(width: 30, height: 30)
                .foregroundColor(.neonBlue)
                .padding(10)
                .background {
                    Circle()
                        .fill(.white)
            }
        }
    }
}

struct LocationButton_Previews: PreviewProvider {
    static var previews: some View {
        LocationButton(action: {})
    }
}
