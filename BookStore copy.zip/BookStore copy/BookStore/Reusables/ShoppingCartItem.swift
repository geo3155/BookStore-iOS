//
//  ShoppingCartItem.swift
//  BookStore
//
//  Created by George Predan on 18.02.2023.
//

import SwiftUI

struct ShoppingCartItem: View {
    var book: Book
    
    init(book: Book) {
        self.book = book
    }
    
    var body: some View {
        HStack(alignment: .top) {
            image
            details
            Spacer()
        }
        .padding(.horizontal)
        .overlay(alignment: .topTrailing) {
            VStack(alignment: .trailing) {
                Button {
                    
                } label: {
                    Image(systemName: "x.circle")
                        .foregroundColor(.red)
                }
                .padding(.trailing)
            }
        }
        .overlay(alignment: .bottomTrailing) {
            QuantityHandlerView()
                .padding(.trailing)
        }
    }
        private var image: some View {
            book.image
                .resizable()
                .frame(width: 90, height: 90)
                .clipShape(RoundedRectangle(cornerRadius: 20))
        }
        
        private var details: some View {
            VStack(alignment: .leading, spacing: 5) {
                VStack(alignment: .leading) {
                    Text(book.name)
                        .font(.Main.regular(size: 18))
                    Text(book.format.rawValue)
                        .font(.Main.regular(size: 14))
                        .foregroundColor(.gray)
                }
                Text("\(book.price.formatted()) RON")
                    .font(.Main.regular(size: 16))
                    .foregroundColor(.neonBlue)
            }
        }
}

struct ShoppingCartItem_Previews: PreviewProvider {
    static var previews: some View {
        ShoppingCartItem(book: Book(name: "Millionaire Success Habits", format: .digital, image: Image("ProfilePhoto"), price: 40.99))
    }
}
