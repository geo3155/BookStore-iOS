//
//  CustomTextField + Style.swift
//  BookStore
//
//  Created by George Predan on 01.12.2022.
//

import SwiftUI

enum TextFieldType {
    case simple, password
}

struct SimpleField: View {
    @FocusState private var isFocused: Bool
    @Binding var text: String
    let name: String
    var type: TextFieldType
    var passwordAction: () -> Void = {}
    var cornerRadius: CGFloat = 10
    
    var body: some View {
        TextField("", text: $text)
            .textFieldStyle(CustomTextFieldStyle(text: text,
                                                 titleKey: name,
                                                 type: type,
                                                 cornerRadius: cornerRadius,
                                                 passwordAction: passwordAction,
                                                 isFocused: isFocused))
            .focused($isFocused)
    }
}

struct CustomTextField: View {
    @Binding var text: String
    let name: String
    var body: some View {
        VStack(alignment: .leading) {
            Text(name)
                .font(.Main.regular(size: 16))
                .foregroundColor(.gray)
            SimpleField(text: $text, name: name, type: .simple)
        }
    }
}

struct CustomTextFieldStyle: TextFieldStyle {
    
    let text: String
    let titleKey: String
    let type: TextFieldType
    var cornerRadius: CGFloat
    var passwordAction: (() -> Void) = {}
    
    var isFocused: Bool = false
    
    func _body(configuration: TextField<Self._Label>) -> some View {
        HStack {
            configuration
                .foregroundColor(.black)
                .font(.Main.regular())
                .accentColor(.neonBlue)
                .background(alignment: .leading) {
                    if text.isEmpty {
                        Text(titleKey)
                            .font(.Main.regular(size: 17))
                            .foregroundColor(.gray)
                    }
                }
            if type == .password {
                Button {
                    passwordAction()
                } label: {
                    Image(systemName: "eye")
                        .foregroundColor(.gray)
                }
                
            }
        }
        .padding(.horizontal, 20)
        .frame(height: 65)
        .overlay {
            RoundedRectangle(cornerRadius: cornerRadius)
                .stroke(lineWidth: 1)
                .fill(isFocused ? Color.neonBlue : Color.gray)
        }
    }
}

struct CustomSecureField: View {
    
    @Binding var text: String
    @State private var showPassword: Bool = false
    @FocusState private var isFocused: Bool
    let name: String
    
    var body: some View {
        
        VStack(alignment: .leading) {
            
            Text(name)
                .foregroundColor(.gray)
                .font(.Main.regular(size: 16))
            
            if showPassword {
                SimpleField(text: $text, name: name, type: .password) {
                    showPassword.toggle()
                }
            } else {
                SecureField("", text: $text)
                //de modificat border cu focused
                    .accentColor(.purple)
                    .textFieldStyle(CustomTextFieldStyle(text: text, titleKey: name, type: .password, cornerRadius: 10, passwordAction:  {
                        showPassword.toggle()
                    }, isFocused: isFocused))
            }
        }
    }
}

struct CustomTextFieldStyle_Previews: PreviewProvider {
    static var previews: some View {
        VStack(spacing: 30) {
            CustomTextField(text: .constant("sdfsdgdsfgd"), name: "Full name")
                
            CustomSecureField(text: .constant("sdfsd"), name: "Password")
        }
    }
}
