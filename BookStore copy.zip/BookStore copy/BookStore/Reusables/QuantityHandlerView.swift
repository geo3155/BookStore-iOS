//
//  QuantityHandlerView.swift
//  BookStore
//
//  Created by George Predan on 25.02.2023.
//

import SwiftUI

struct QuantityHandlerView: View {
    @State var quantity: Int = 0
    var body: some View {
        HStack {
            Button {
                quantity -= 1
            } label: {
                Image(systemName: "minus.circle")
                    .resizable()
                    .frame(width: 28, height: 28)
                    .foregroundColor(.neonBlue)
            }
            .buttonStyle(.plain)
            Text(quantity.description)
                .font(.Main.regular(size: 18))
            Button {
                quantity += 1
            } label: {
                Image(systemName: "plus.circle.fill")
                    .resizable()
                    .frame(width: 28, height: 28)
                    .foregroundColor(.neonBlue)
            }
            .buttonStyle(.plain)
        }
    }
}

struct QuantityHandlerView_Previews: PreviewProvider {
    static var previews: some View {
        QuantityHandlerView()
    }
}
