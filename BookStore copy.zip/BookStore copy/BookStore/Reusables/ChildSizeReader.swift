//
//  ChildSizeReader.swift
//  BookStore
//
//  Created by George Predan on 09.02.2023.
//

import SwiftUI

struct ChildSizeReader<Content: View>: View {
    @Binding var size: CGSize
        let content: () -> Content
        var body: some View {
            ZStack {
                content()
                    .background(
                        GeometryReader { proxy in
                            Color.clear
                                .preference(key: SizePreferenceKey.self, value: proxy.size)
                        }
                    )
            }
            .onPreferenceChange(SizePreferenceKey.self) { preference in
                size = preference
            }
        }
}

struct SizePreferenceKey: PreferenceKey {
    typealias Value = CGSize
    static var defaultValue: CGSize = .zero
    
    static func reduce(value: inout CGSize, nextValue: () -> CGSize) {
        _ = nextValue()
    }
}

struct ChildSizeReader_Previews: PreviewProvider {
    static var previews: some View {
        ChildSizeReader(size: .constant(CGSize(width: 100, height: 100)), content: {
            Color.red
        })
    }
}
