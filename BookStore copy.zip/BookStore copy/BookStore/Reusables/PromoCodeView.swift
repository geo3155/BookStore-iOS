//
//  PromoCodeView.swift
//  BookStore
//
//  Created by George Predan on 19.02.2023.
//

import SwiftUI

struct PromoCodeView: View {
    var body: some View {
        SimpleField(text: .constant(""), name: "Promo Code", type: .simple, cornerRadius: 100)
            .overlay(alignment: .trailing) {
                applyButton
            }
            .padding()
    }
    private var applyButton: some View {
        Button {
            
        } label: {
            RoundedRectangle(cornerRadius: 29)
                .fill(Color.neonBlue)
                .frame(width: 100)
                .padding(.vertical, 4)
                .padding(.horizontal, 8)
                .overlay {
                    Text("Apply")
                        .font(.Main.regular(size: 18))
                        .foregroundColor(.white)
                }
        }

    }
}

struct PromoCodeView_Previews: PreviewProvider {
    static var previews: some View {
        PromoCodeView()
    }
}
