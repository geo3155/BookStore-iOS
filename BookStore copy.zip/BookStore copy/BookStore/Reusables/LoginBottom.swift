//
//  LoginBottom.swift
//  BookStore
//
//  Created by George Predan on 03.12.2022.
//

import SwiftUI

enum BottomType: Equatable {
    case register, login
}

struct LoginText: View {
    let type: BottomType
    let action: () -> Void
    
    var body: some View {
        HStack {
            Text("\(type == .register ? "Already have an account?": "Don’t have an account?")")
                .font(.Main.regular(size: 14))
                .accentColor(.neonBlue)
            Button {
                action()
            } label: {
                Text("\(type == .register ? "Login" : "Sign Up")")
                    .font(.Main.regular(size: 14))
                    .foregroundColor(.neonBlue)
            }
            .buttonStyle(.plain)
            
        }
    }
}

struct LoginBottom: View {
    //array SocialApp
    let bottomType: BottomType
    var textColor: Color = .black
    
    var body: some View {
        VStack {
            section
            signOptions
        }
    }
    /*
     struct SocialApp {
     title
     icon
     or enum
     */
    private func socialButton(imageName: String, title: String) -> some View {
        Button {
            
        } label: {
            RoundedRectangle(cornerRadius: 28.5)
                .fill(.white)
                .shadow(radius: 0.5)
                .overlay {
                    HStack {
                        Image(imageName)
                            .resizable()
                            .frame(width: 38, height: 38)
                        Text(title)
                            .font(.Main.regular(size: 13))
                            .foregroundColor(.black)
                    }
                }
        }
        .buttonStyle(.plain)
    }
    
    private var section: some View {
        HStack {
            Rectangle()
                .fill(.gray)
                .frame(height: 0.5)
            
            Text(bottomType == .register ? "Sign up with" : "Sign in with")
                .foregroundColor(textColor)
                .font(.Main.regular(size: 14))
            
            Rectangle()
                .fill(.gray)
                .frame(height: 0.5)
        }
        .padding(.horizontal)
    }
    
    
    private var signOptions: some View {
        HStack(spacing: 20) {
            socialButton(imageName: "Facebook_logo", title: "FACEBOOK")
            socialButton(imageName: "Google_Logo", title: "GOOGLE")
            
            
        }
        .padding(.horizontal)
        .frame(height: 57)
    }
}

struct LoginBottom_Previews: PreviewProvider {
    static var previews: some View {
        LoginBottom(bottomType: .register)
    }
}
