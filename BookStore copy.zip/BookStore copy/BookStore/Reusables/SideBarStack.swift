//
//  SideBarStack.swift
//  BookStore
//
//  Created by George Predan on 09.02.2023.
//

import SwiftUI

struct SideBarStack<SideBarContent: View, Content: View>: View {
    
    let sideBarContent: SideBarContent
    let mainContent: Content
    @Binding var showSideBar: Bool
    @State private var sidebarSize: CGSize = .zero
    
    init(@ViewBuilder sideBarContent: () -> SideBarContent, @ViewBuilder mainContent: () -> Content, showSideBar: Binding<Bool>) {
        self.sideBarContent = sideBarContent()
        self.mainContent = mainContent()
        self._showSideBar = showSideBar
    }
    
    
    var body: some View {
        ZStack(alignment: .leading) {
            ChildSizeReader(size: $sidebarSize, content: {
                sideBarContent
            })
            .offset(x: showSideBar ? 0 : -1 * sidebarSize.width)
            .animation(.default.speed(2), value: showSideBar)
            mainContent
                .offset(x: showSideBar ? sidebarSize.width : 0)
                .onTapGesture {
                    guard showSideBar == true else {
                        return
                    }
                    showSideBar = false
                }
                .animation(.default.speed(2), value: showSideBar)
        }
    }
}

struct SideBarStack_Previews: PreviewProvider {
    static var previews: some View {
        SideBarStack(sideBarContent: {
            Color.red
                .frame(width: 100)
        }, mainContent: {
            Home.ContentView(viewModel: Home.ViewModel(profileAction: {}, myOrdersAction: {}, settingsAction: {}))
        }, showSideBar: .constant(false))
    }
}


