//
//  OrderItemView.swift
//  BookStore
//
//  Created by George Predan on 26.02.2023.
//

import SwiftUI

struct OrderItemView: View {
    let book: BookFireStore
    let orderStatus: OrderStatus
    var body: some View {
        VStack {
            HStack {
                book.image
                    .resizable()
                    .frame(width: 65, height: 65)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                VStack(alignment: .leading, spacing: 10) {
                    Text(book.name)
                        .font(.Main.regular(size: 18))
                    orderDetails
                }
                Spacer()
                Text("\(book.price.formatted()) RON")
                    .foregroundColor(.neonBlue)
                    .font(.Main.regular(size: 20))
            }
            .padding(.horizontal)
            cancelButton
        }
        .padding(.vertical)
        .background(RoundedRectangle(cornerRadius: 18)
            .fill(.white)
            .shadow(radius: 2))
//        .padding(.horizontal)
    }
    
    private var orderDetails: some View {
        HStack(spacing: 2) {
            Image(systemName: "circle.fill")
                .resizable()
                .foregroundColor(orderStatus.color)
                .frame(width: 12, height: 12)
            Text(orderStatus.description)
                .font(.Main.bold(size: 14))
                .foregroundColor(orderStatus.color)
        }
    }
    private var cancelButton: some View {
        Button {
            
        } label: {
            Text("Cancel")
                .foregroundColor(.black)
                .font(.Main.bold(size: 16))
                .padding()
                .background(RoundedRectangle(cornerRadius: 16)
                    .fill(.white))
                .shadow(radius: 2)
        }
        .buttonStyle(.plain)
    }
}

struct OrderItemView_Previews: PreviewProvider {
    static var previews: some View {
        OrderItemView(book: BookFireStore(id: "", name: "", author: "", price: 88.18, image: Image("")), orderStatus: .cancelled)
    }
}

enum OrderStatus {
    
    case inProgress
    case delivered
    case cancelled
    
    var color: Color {
        switch self {
        case .delivered:
            return .green
        case .inProgress:
            return .black
        case .cancelled:
            return .red
        }
    }

    var description: String {
        switch self {
        case .delivered:
            return "Order delivered"
        case .inProgress:
            return "In progress"
        case .cancelled:
            return "Canecelled"
        }
    }
}
