//
//  FavoriteItem.swift
//  BookStore
//
//  Created by George Predan on 20.02.2023.
//

import SwiftUI

struct FavoriteItem: View {
    let book: BookFireStore
    var body: some View {
        VStack {
            VStack(alignment: .leading, spacing: 15) {
                image
                VStack(alignment: .leading) {
                    Text(book.name)
                        .font(.Main.regular(size: 20))
                        .padding(.leading)
                    Text("book.format.rawValue")
                        .padding(.leading)
                        .font(.Main.regular(size: 17))
                        .foregroundColor(.gray)
                }
            }
            .padding(.bottom)
            .background {
                RoundedRectangle(cornerRadius: 18)
                    .fill(.white)
            }
            .padding(.horizontal)
        }
    }
    
    private var image: some View {
        Image("FavoriteItem")
            .resizable()
            .frame(height: 228)
            .clipShape(RoundedRectangle(cornerRadius: 18))
            .overlay(alignment: .top) {
                topDetails
            }
            .overlay(alignment: .bottomLeading) {
                rateDetails
            }
    }
    
    private var topDetails: some View {
        HStack {
            HStack {
                Text(book.price.description)
                    .font(.Main.regular(size: 20))
                Text("RON")
                    .foregroundColor(.neonBlue)
                    .font(.Main.regular(size: 20))
            }
            .padding(8)
            .background {
                RoundedRectangle(cornerRadius: 121)
                    .fill(.white)
            }
            Spacer()
            StarButton()
            
        }
        .padding()
    }
    
    private var rateDetails: some View {
        HStack {
            Text("4.5")
                .font(.Main.regular(size: 15))
            Image(systemName: "star.fill")
                .foregroundColor(.maxBluePurple)
            Text("(25+)")
                .font(.Main.regular(size: 10))
                .foregroundColor(.gray)
        }
        .padding(8)
        .background {
            RoundedRectangle(cornerRadius: 12)
                .fill(.white)
        }
        .padding(.leading)
        .padding(.bottom, -10)
    }
    
}

struct FavoriteItem_Previews: PreviewProvider {
    static var previews: some View {
        FavoriteItem(book: BookFireStore(id: "", name: "", author: "", price: 21, image: Image("")))
    }
}
