//
//  LogOutButton.swift
//  BookStore
//
//  Created by George Predan on 10.02.2023.
//

import SwiftUI

struct LogOutButton: View {
    
    let action: () -> Void
    var body: some View {
        Button {
            action()
        } label: {
            HStack {
                powerOff
                Text("Log Out")
                    .font(.Main.regular(size: 16))
                    .foregroundColor(.white)
            }
            .padding(.horizontal)
            .padding(.vertical, 10)
            .background {
                RoundedRectangle(cornerRadius: 28)
                    .fill(Color.neonBlue)
            }
        }
        .buttonStyle(.plain)
    }
    
    private var powerOff: some View {
        Image(systemName: "power")
            .resizable()
            .frame(width: 18, height: 18)
            .foregroundColor(.neonBlue)
            .padding(5)
            .background(Circle()
                .fill(.white))
    }
}

struct LogOutButton_Previews: PreviewProvider {
    static var previews: some View {
        LogOutButton(action: {
            
        })
    }
}
