//
//  UserRepository.swift
//  BookStore
//
//  Created by George Predan on 11.03.2023.
//

import Foundation

class UserRepository: ObservableObject {
    @Published private(set) var user: User?
    
    static let shared: UserRepository = .init()
    
    private init() {
        user = Session.user
    }
    
    func updateUser(fullName: String, email: String, password: String) {
        guard user?.id != nil else {
            saveInitialUser(fullName: fullName, email: email, password: password)
            Session.user = user
            return
        }
        
        user?.email = email
        user?.userName = fullName
        user?.password = password
        
        
        Session.user = user
    }
    
    private func saveInitialUser(fullName: String, email: String, password: String) {
        self.user = User(id: UUID().uuidString, userName: fullName, email: email, password: password)
    }
}

struct User: Codable {
    let id: String
    var userName: String
    var email: String
    var password: String
}
