//
//  Book.swift
//  BookStore
//
//  Created by George Predan on 18.02.2023.
//

import Foundation
import SwiftUI
import FirebaseFirestore
import FirebaseStorage

@propertyWrapper
struct PositiveValue<T: Numeric & Comparable> {
    
    var wrappedValue: T {
        get {
            return max(0, (internalValue ?? 0))
        }
        set {
            internalValue = newValue
        }
    }
    private var internalValue: T?
    
    init(wrappedValue: T) {
        self.wrappedValue = wrappedValue
    }
    
}

struct Book {
    
    let name: String
    let format: Format
    let image: Image
    let price: Double
    @PositiveValue var quantity: Int = 1
}


struct BookFireStore {
    
    let id: String
    var name: String
    var author: String
    var price: Double
    var image: Image
    
}

extension BookFireStore {
    
    init?(queryDocument: QueryDocumentSnapshot) {
        self.id = queryDocument.documentID
        guard let name = queryDocument["name"] as? String,
              let author = queryDocument["author"] as? String,
              let price = queryDocument["price"] as? Double,
        let imagePath = queryDocument["image"] as? String else {
            print("Init failed")
            return nil
        }
        
        func getPhotos(path: String) -> Image {
            var image: Image?
            
            let storageRef = Storage.storage().reference()
            let fileRef = storageRef.child(path)
            
            fileRef.getData(maxSize: 1000 * 1024 * 1024) { data, error in
                if let error = error {
                    print(error.localizedDescription)
                }
                if let data = data, let uiImage = UIImage(data: data) {
                    image = Image(uiImage: uiImage)
                }
            }
            return image ?? Image("")
        }
        
        self.name = name
        self.author = author
        self.price = price
        self.image = getPhotos(path: imagePath)
    }
    
}

enum Format: String {
    case digital = "This is a book in digital format"
    case audioBook = "This is an audio book"
    case hardCover = "This is a hard cover book"
}
