//
//  Library.swift
//  BookStore
//
//  Created by George Predan on 17.02.2023.
//

import Foundation
import MapKit

struct Library: Identifiable {
    let id = UUID()
    let coordinates: CLLocationCoordinate2D
}
