//
//  Color+Extension.swift
//  BookStore
//
//  Created by George Predan on 28.11.2022.
//

import Foundation
import SwiftUI

extension Color {
    public static let neonBlue: Color = Color("Neon Blue")
    public static let maxBluePurple: Color = Color("Maximum Blue Purple")
    public static let tomato: Color = Color("Tomato")
    public static let platinum: Color = Color("Platiinum")
}
