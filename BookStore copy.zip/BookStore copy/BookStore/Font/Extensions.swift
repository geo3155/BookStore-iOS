//
//  Extensions.swift
//  BookStore
//
//  Created by George Predan on 09.02.2023.
//

import Foundation
import UIKit
import SwiftUI

extension UIViewController {
    
    func configureTabBarItem(title: String? = nil, selectedImage: UIImage?) {
        tabBarItem.title = title
        tabBarItem.selectedImage = selectedImage?.withTintColor(UIColor(Color.neonBlue), renderingMode: .alwaysOriginal)
        tabBarItem.image = selectedImage?.withTintColor(UIColor(Color.neonBlue))
    }
}
