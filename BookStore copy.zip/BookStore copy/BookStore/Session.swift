//
//  Session.swift
//  BookStore
//
//  Created by George Predan on 28.11.2022.
//

import Foundation
import SwiftUI

struct Session {
    @UserDefault(key: "didInstallApp", defaultValue: false)
    static var didInstallApp: Bool
    
    @UserDefault(key: "profilePhoto", defaultValue: Image("ProfilePhoto"))
    static var profilePhoto: Image
    
    @ObjectUserDefault(key: "user", defaultValue: nil)
    static var user: User?
}

@propertyWrapper
struct UserDefault<T> {
    
    var key: String
    var defaultValue: T
    
    var wrappedValue: T {
        get {
            let value = UserDefaults.standard.value(forKey: key) as? T
            return value ?? defaultValue
        } set {
            UserDefaults.standard.set(newValue, forKey: key)
            UserDefaults.standard.synchronize()
        }
    }
    
}

@propertyWrapper
struct ObjectUserDefault<T: Codable> {
    let key: String
    let defaultValue: T
    
    var wrappedValue: T {
        get {
            let object = UserDefaults.standard.object(forKey: key) as? Data
            switch object as Any {
            case Optional<Any>.some:
                let decodedObject = try? JSONDecoder().decode(T.self, from: object!) as T
                return decodedObject ?? defaultValue
            case Optional<Any>.none:
                return defaultValue
            default:
                return defaultValue
            }
        }
        set {
            let encodedObject = try? JSONEncoder().encode(newValue)
            switch newValue as Any {
            case Optional<Any>.some:
                UserDefaults.standard.set(encodedObject, forKey: key)
            case Optional<Any>.none:
                UserDefaults.standard.removeObject(forKey: key)
            default:
                UserDefaults.standard.set(encodedObject, forKey: key)
            }
            UserDefaults.standard.synchronize()
        }
    }
}
