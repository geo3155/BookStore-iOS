//
//  AppDelegate.swift
//  BookStore
//
//  Created by George Predan on 28.11.2022.
//

import UIKit
import SwiftUI
import FirebaseCore

@main
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    var window: UIWindow?
    private var rootCoordinator: RootCoordinator?
    
    func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
    ) -> Bool {
        
        let window = UIWindow(frame: UIScreen.main.bounds)
        self.rootCoordinator = RootCoordinator(window: window)
        rootCoordinator?.start()
        self.window = window
        self.window?.makeKeyAndVisible()
        
        FirebaseApp.configure()
        return true
    }
}

