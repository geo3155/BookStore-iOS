//
//  SplashScreenViewController.swift
//  BookStore
//
//  Created by George Predan on 28.11.2022.
//

import Foundation
import UIKit
import SwiftUI

extension SplashScreen {
    class ViewController: UIHostingController<ContentView> {
        init(nextCoordinatorAction: @escaping () -> Void) {
            super.init(rootView: ContentView(nextCoordinatorAction: nextCoordinatorAction))
        }
        
        override var preferredStatusBarStyle: UIStatusBarStyle {
            return .lightContent
        }
        
        @MainActor required dynamic init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
}
