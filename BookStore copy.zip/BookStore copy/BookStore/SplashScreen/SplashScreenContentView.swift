//
//  SplashScreen.swift
//  BookStore
//
//  Created by George Predan on 28.11.2022.
//

import SwiftUI

struct SplashScreen {
    struct ContentView: View {
        
        let nextCoordinatorAction: () -> Void
        
        var body: some View {
            VStack {
                Image("BookStoreLogo")
                    .resizable()
                    .frame(width: 93, height: 93)
                
                Text("BookStore")
                    .font(.Main.regular(size: 30))
                    .foregroundColor(.white)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color.neonBlue)
            .task {
                try? await Task.sleep(nanoseconds: 1_500_000_000)
                nextCoordinatorAction()
            }
        }
    }
}

struct SplashScreen_Previews: PreviewProvider {
    static var previews: some View {
        SplashScreen.ContentView(nextCoordinatorAction: {})
    }
}
