//
//  WelcomeView.swift
//  BookStore
//
//  Created by George Predan on 18.01.2023.
//

import SwiftUI

struct WelcomeView: View {
    let action: () -> ()
    let loginAction: () -> ()
    let registerAction: () -> ()
    var body: some View {
        VStack {
            skipButton
            VStack(alignment: .leading, spacing: 20) {
                welcomeTitle
                
                Text("Your favorite books,\n in just a moment")
                    .font(.Main.regular(size: 18))
                    .foregroundColor(.white)
                Spacer()
                LoginBottom(bottomType: .login, textColor: .white)
                signUpButton
            }
            loginText
        }
        .padding(.horizontal)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(GeometryReader(content: { proxy in
            Image("WelcomeImage")
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(width: proxy.size.width, height: proxy.size.height)
        })
            .ignoresSafeArea(.container, edges: .vertical))
        
    }
    
    private var signUpButton: some View {
        Button {
            registerAction()
        } label: {
            RoundedRectangle(cornerRadius: 30)
            //                .strokeBorder(lineWidth: 2, antialiased: true)
                .fill(.white)
                .opacity(0.21)
                .frame(height: 54)
                .overlay {
                    ZStack {
                        RoundedRectangle(cornerRadius: 30)
                            .stroke(lineWidth: 1)
                            .fill(.white)
                        Text("Start with email")
                            .font(.Main.regular(size: 17))
                            .foregroundColor(.white)
                    }
                }
                .padding(.horizontal)
        }
        .buttonStyle(.plain)
    }
    
    private var skipButton: some View {
        HStack {
            Spacer()
            Button {
                action()
            } label: {
                Text("Skip")
                    .font(.Main.regular(size: 14))
                    .foregroundColor(.neonBlue)
                    .padding(.vertical, 10)
                    .padding(.horizontal, 16)                   .background(RoundedRectangle(cornerRadius: 28)
                        .fill(.white))
            }
            .buttonStyle(.plain)
        }
    }
    
    private var welcomeTitle: some View {
        VStack(alignment: .leading) {
            Text("Welcome to")
                .font(.Main.bold(size: 45))
                .foregroundColor(.white)
            Text("BookStore")
                .font(.Main.bold(size: 45))
                .foregroundColor(.neonBlue)
        }
    }
    
    private var loginText: some View {
        HStack {
            Text("Already have an account?")
                .foregroundColor(.white)
                .font(.Main.regular(size: 16))
            Button {
                loginAction()
            } label: {
                Text("Sign in")
                    .foregroundColor(.white)
                    .font(.Main.regular(size: 16))
                    .underline(true, color: .white)
            }

        }
    }
}

struct WelcomeView_Previews: PreviewProvider {
    static var previews: some View {
        WelcomeView {
            
        } loginAction: {
            
        } registerAction: {
            
        }
        
    }
}
