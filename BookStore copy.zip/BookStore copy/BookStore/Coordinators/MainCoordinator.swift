//
//  MainCoordinator.swift
//  BookStore
//
//  Created by George Predan on 28.11.2022.
//

import Foundation
import UIKit
import SwiftUI

class MainCoordinator: Coordinator {
    
    let navigationController: UINavigationController
    let tabbarController = CustomTabBarController()
    let onFinishedInteraction: () -> Void
    
    init(navigationController: UINavigationController, onFinishedInteraction: @escaping () -> Void) {
        self.navigationController = navigationController
        self.onFinishedInteraction = onFinishedInteraction
    }
    
    func start() {
        let homeVC = Home.ViewController {
            let profileSettingsVC = ProfileSettings.ViewController(backAction: {
                self.navigationController.popViewController(animated: true)
            })
            self.navigationController.pushViewController(profileSettingsVC, animated: true)
        } myOrdersAction: {
            let myOrdersVC = MyOrders.ViewController {
                self.navigationController.popViewController(animated: true)
            }
            self.navigationController.pushViewController(myOrdersVC, animated: true)
        } settingsAction: {

        }

        let mapVC = MapView.ViewController()
        let shoppingCartVC = ShoppingCart.ViewController()
        let favoriteVC = Favorite.ViewController()
        let settingsVC = Settings.ViewController()
        
        tabbarController.setViewControllers([homeVC, mapVC, shoppingCartVC, favoriteVC, settingsVC], animated: false)
        navigationController.pushViewController(tabbarController, animated: true)
    }
    
}

class CustomTabBarController: UITabBarController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tabBar.backgroundColor = .white
//        tabBar.tintColor = .green
        tabBar.layer.cornerRadius = 10
        
    }
    
}
