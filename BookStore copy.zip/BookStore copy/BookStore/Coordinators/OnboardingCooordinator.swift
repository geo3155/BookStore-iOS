//
//  OnboardingCooordinator.swift
//  BookStore
//
//  Created by George Predan on 28.11.2022.
//

import Foundation
import UIKit
import SwiftUI

class OnboardingCoordinator: Coordinator {
    
    let navigationController: UINavigationController
    let onFinishedInteraction: () -> Void
    var signUpCoordinator: SignUpCoordinator?
    var signInCoordinator: SignInCoordinator?
    var mainCoordinator: MainCoordinator?
    
    init(navigationController: UINavigationController, onFinishedInteraction: @escaping () -> Void) {
        self.navigationController = navigationController
        self.onFinishedInteraction = onFinishedInteraction
    }
    
    func start() {
        showWelcomeView()
    }
    
    private func showWelcomeView() {
        let welcomeVC = UIHostingController(rootView: WelcomeView(
            action: {
                self.configureMainCoordinator()
            }, loginAction: {
                self.configureSignInCoordinator()
            }, registerAction: {
                self.configureSignUpCoordinator()
            }))
        navigationController.pushViewController(welcomeVC, animated: true)
    }
    
    private func configureCoordinator() {
        self.signUpCoordinator = nil
        self.signInCoordinator = nil
        self.mainCoordinator = nil
        self.onFinishedInteraction()
    }
    
    private func configureSignUpCoordinator() {
        signUpCoordinator = .init(navigationController: navigationController, onFinishedInteraction: {
            self.configureCoordinator()
        })
        self.signUpCoordinator?.start()
    }
    
    private func configureSignInCoordinator() {
        signInCoordinator = .init(navigationController: navigationController, onFinishedInteraction: {
            self.configureCoordinator()
        })
        self.signInCoordinator?.start()
        
    }
    
    private func configureMainCoordinator() {
        mainCoordinator = .init(navigationController: navigationController, onFinishedInteraction: {
            self.configureCoordinator()
        })
        mainCoordinator?.start()
    }
}
