//
//  Coordinator.swift
//  BookStore
//
//  Created by George Predan on 28.11.2022.
//

import Foundation
import UIKit
import SwiftUI

protocol Coordinator {
    func start()
//    var onFinishedInteraction: () -> Void { get }
}

class RootCoordinator: Coordinator {
    
    var window: UIWindow
    private let navigationController: UINavigationController
    
    //COORDNATORS	
    var mainCoordinator: MainCoordinator?
    var onboardingCoordinator: OnboardingCoordinator?
    
    init(window: UIWindow) {
        self.window = window
        self.navigationController = UINavigationController()
        self.navigationController.navigationBar.isHidden = true
        
    }
    
    func start() {
        let splashVC = SplashScreen.ViewController(nextCoordinatorAction: {
            UIView.transition(with: self.window, duration: 0.3, options: .transitionCrossDissolve) {
                self.window.rootViewController = self.navigationController
                if Session.didInstallApp {
                    self.showMainCoordinator()
                } else {
                    self.showOnboardingCoordinator()
                }
            }
        })
        self.window.rootViewController = splashVC
        window.makeKeyAndVisible()
    }
    
    func showMainCoordinator() {
        mainCoordinator = .init(navigationController: navigationController, onFinishedInteraction: {
            
        })
        mainCoordinator?.start()
        onboardingCoordinator = nil
    }
    
    func showOnboardingCoordinator() {
        mainCoordinator = nil
        onboardingCoordinator = .init(navigationController: navigationController, onFinishedInteraction: {
            self.showMainCoordinator()
        })
        onboardingCoordinator?.start()
    }
}
