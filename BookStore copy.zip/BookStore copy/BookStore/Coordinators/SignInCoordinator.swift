//
//  SigninCoordinator.swift
//  BookStore
//
//  Created by George Predan on 12.01.2023.
//

import Foundation
import UIKit
import SwiftUI

class SignInCoordinator: Coordinator {
    
    let navigationController: UINavigationController
    let onFinishedInteraction: () -> Void
    var mainCoordinator: MainCoordinator?
    var resetPassCoordinator: ResetPassCoordinator?
    
    init(navigationController: UINavigationController, onFinishedInteraction: @escaping () -> Void) {
        self.navigationController = navigationController
        self.onFinishedInteraction = onFinishedInteraction
    }
    
    func start() {
        let logInVC = Login.ViewController {
            self.navigationController.popViewController(animated: true)
        } onResetPass: {
            self.configureResetPassCoordinator()
        } onLogin: {
            self.configureMainCoordinator()
        }

        navigationController.pushViewController(logInVC, animated: true)
    }
    
    private func configureMainCoordinator() {
        mainCoordinator = .init(navigationController: navigationController, onFinishedInteraction: {
            self.configureCoordinator()
        })
        mainCoordinator?.start()
    }
    
    private func configureResetPassCoordinator() {
        resetPassCoordinator = .init(navigationController: navigationController, onFinished: {
            self.configureCoordinator()
        })
        resetPassCoordinator?.start()
    }
    
    private func configureCoordinator() {
        self.mainCoordinator = nil
        self.resetPassCoordinator = nil
        onFinishedInteraction()
    }
}
