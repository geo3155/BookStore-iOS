//
//  ResetPassCoordinator.swift
//  BookStore
//
//  Created by George Predan on 22.01.2023.
//

import Foundation
import UIKit

class ResetPassCoordinator: Coordinator {
    
    var navigationController: UINavigationController
    let onFinished: () -> Void
    
    init(navigationController: UINavigationController, onFinished: @escaping () -> Void) {
        self.navigationController = navigationController
        self.onFinished = onFinished
    }
    
    func start() {
        let resetPassVC = ResetPass.ViewController {
            self.navigationController.popViewController(animated: true)
        }
        navigationController.pushViewController(resetPassVC, animated: true)
    }
}
