//
//  SignUpCoordinator.swift
//  BookStore
//
//  Created by George Predan on 18.01.2023.
//

import Foundation
import UIKit
import SwiftUI

class SignUpCoordinator: Coordinator {
    
    let navigationController: UINavigationController
    let onFinishedInteraction: () -> Void
    var mainCoordinator: MainCoordinator?
    
    init(navigationController: UINavigationController, onFinishedInteraction: @escaping () -> Void) {
        self.navigationController = navigationController
        self.onFinishedInteraction = onFinishedInteraction
    }
    
    func start() {
        showRegisterView()
    }
    
    func showRegisterView() {
        let registerVC = Register.ViewController(onRegister: configureMainCoordinator) {
            self.navigationController.popViewController(animated: true)
        }
        navigationController.pushViewController(registerVC, animated: true)
    }
    
    func configureMainCoordinator() {
        mainCoordinator = .init(navigationController: navigationController, onFinishedInteraction: {
            self.mainCoordinator = nil
        })
        mainCoordinator?.start()
    }
}
