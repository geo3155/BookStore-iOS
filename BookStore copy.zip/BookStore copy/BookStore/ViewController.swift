//
//  ViewController.swift
//  BookStore
//
//  Created by George Predan on 28.11.2022.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

