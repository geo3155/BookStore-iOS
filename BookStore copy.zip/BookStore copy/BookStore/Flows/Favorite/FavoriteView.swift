//
//  FavoriteView.swift
//  BookStore
//
//  Created by George Predan on 09.02.2023.
//

import SwiftUI

struct Favorite {
    struct ContentView: View {
        @StateObject var viewModel: ViewModel
        var body: some View {
            VStack {
                ScrollView {
                    LazyVStack(pinnedViews: .sectionHeaders) {
                        Section(content: {
                            ForEach(viewModel.books, id: \.id) {FavoriteItem(book: $0)}
                        }, header: {
                            topSettings
                        })
                    }
                }
            }
            .viewTitleInLine(title: "Favorites")
//            .onAppear {
//                viewModel.books = FirestoreFunctions.getData()
//            }
        }
        
        private var topSettings: some View {
            HStack {
                HStack {
                    Text("Sort by:")
                        .font(.Main.regular(size: 16))
                    Picker("ssdf", selection: $viewModel.sortType) {
                        ForEach(SortTypes.allCases, id: \.self) { item in
                            Text(item.rawValue.description.capitalized)
                                .font(.Main.regular(size: 16))
                        }
                    }
                    .accentColor(.neonBlue)
                }
                Spacer()
                Button {
                    
                } label: {
                    SettingIcon()
                        .scaleEffect(0.7)
                }
                .buttonStyle(.plain)
            }
            .background {
                Rectangle()
                    .fill(.white)
            }
            .padding(.horizontal)
        }
    }
}

enum SortTypes: String, CaseIterable {
    case popular
    case ascendent
    case descendent
}


struct FavoriteView_Previews: PreviewProvider {
    static var previews: some View {
        Favorite.ContentView(viewModel: Favorite.ViewModel())
    }
}
