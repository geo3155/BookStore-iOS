//
//  FavoriteViewModel.swift
//  BookStore
//
//  Created by George Predan on 06.03.2023.
//

import Foundation
import FirebaseFirestore

extension Favorite {
    class ViewModel: ObservableObject {
        @Published var sortType: SortTypes = .popular
        @Published var books: [BookFireStore] = []
        
    }
}
