//
//  LoginViewController.swift
//  BookStore
//
//  Created by George Predan on 12.01.2023.
//

import Foundation
import SwiftUI

extension Login {
    
    class ViewController: UIHostingController<ContentView> {
        
        let onBack: () -> Void
        let onResetPass: () -> Void
        let onLogin: () -> Void
        
        init(onBack: @escaping () -> Void, onResetPass: @escaping () -> Void, onLogin: @escaping () -> Void) {
            self.onBack = onBack
            self.onResetPass = onResetPass
            self.onLogin = onLogin
            super.init(rootView: ContentView(viewModel: Login.ViewModel(onBack: self.onBack, onResetPass: self.onResetPass, onLogin: self.onLogin)))
        }
        
        @MainActor required dynamic init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
}
