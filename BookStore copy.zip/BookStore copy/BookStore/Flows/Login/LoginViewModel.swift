//
//  LoginViewModel.swift
//  BookStore
//
//  Created by George Predan on 12.01.2023.
//

import Foundation

extension Login {
    class ViewModel: ObservableObject {
        @Published var email: String = ""
        @Published var password: String = ""
        let userRepository = UserRepository.shared
        
        let onBack: () -> Void
        let onResetPass: () -> Void
        let onLogin: () -> Void
        
        init(onBack: @escaping () -> Void, onResetPass: @escaping () -> Void, onLogin: @escaping () -> Void) {
            self.onBack = onBack
            self.onResetPass = onResetPass
            self.onLogin = onLogin
        }
        
        func loggedIn() {
            guard userRepository.user != nil else {
                return
            }
            onLogin()
        }
    }
}
