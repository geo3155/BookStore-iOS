//
//  LoginView.swift
//  BookStore
//
//  Created by George Predan on 12.01.2023.
//

import SwiftUI

struct Login {
    struct ContentView: View {
        
        @StateObject var viewModel: ViewModel
        
        var body: some View {
            ScrollView {
                VStack(spacing: 30) {
                    VStack(alignment: .leading, spacing: 30) {
                        
                        BackButton(action: viewModel.onBack)
                        Spacer()
                        Text("Login")
                            .font(.Main.bold(size: 36))
                        
                        CustomTextField(text: $viewModel.email, name: "E-mail")
                        
                        CustomSecureField(text: $viewModel.password, name: "Password")
                    }
                    
                    Button {
                        viewModel.onResetPass()
                    } label: {
                        Text("Forgot your password")
                            .font(.Main.regular(size: 14))
                            .foregroundColor(.neonBlue)
                    }
                    .buttonStyle(.plain)
                    
                    LoginButton(title: "LOGIN") {
                        viewModel.loggedIn()
                    }
                    LoginBottom(bottomType: .login)
                }
                .padding()
            }
        }
    }
}

struct LoginView_Previews: PreviewProvider {
    static var previews: some View {
        Login.ContentView(viewModel: Login.ViewModel(onBack: {}, onResetPass: {}, onLogin: {}))
    }
}
