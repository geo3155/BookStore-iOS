//
//  ResetPass.swift
//  BookStore
//
//  Created by George Predan on 22.01.2023.
//

import Foundation
import SwiftUI

extension ResetPass {
    class ViewController: UIHostingController<ContentView> {
        
        let backAction: () -> Void
        
        init(backAction: @escaping () -> Void) {
            self.backAction = backAction
            super.init(rootView: ContentView(viewModel: ViewModel(backAction: self.backAction)))
        }
        
        @MainActor required dynamic init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
}
