//
//  ViewModel.swift
//  BookStore
//
//  Created by George Predan on 22.01.2023.
//

import Foundation

extension ResetPass {
    class ViewModel: ObservableObject {
        
        @Published var text: String = ""
        let backAction: () -> Void
        
        init(backAction: @escaping () -> Void) {
            self.backAction = backAction
        }
    }
}
