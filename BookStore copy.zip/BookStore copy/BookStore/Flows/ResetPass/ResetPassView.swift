//
//  ResetPassView.swift
//  BookStore
//
//  Created by George Predan on 22.01.2023.
//

import SwiftUI

struct ResetPass {
    struct ContentView: View {
        
        @StateObject var viewModel: ViewModel
        
        var body: some View {
            VStack(spacing: 30) {
                ZStack(alignment: .leading) {
                    button
                        VStack(alignment: .leading, spacing: 30) {
                            Text("Reset Password")
                                .font(.Main.bold(size: 37))
                            
                            Text("Please enter your email address to request a password reset")
                                .font(.Main.regular(size: 14))
                                .foregroundColor(.gray)
                            
                            SimpleField(text: $viewModel.text, name: "Email", type: .simple)
                        }
                        .padding(.horizontal)
                    
                }
                LoginButton(title: "Send new password") {

                }
            }
        }
        
        private var button: some View {
            VStack(alignment: .leading) {
                BackButton(action: viewModel.backAction)
                Spacer()
            }
            .padding(.all)
        }
    }
}

struct ResetPassView_Previews: PreviewProvider {
    static var previews: some View {
        ResetPass.ContentView(viewModel: ResetPass.ViewModel(backAction: {
            
        }))
    }
}
