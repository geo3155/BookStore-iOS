//
//  HomeViewController.swift
//  BookStore
//
//  Created by George Predan on 28.11.2022.
//

import Foundation
import UIKit
import SwiftUI

extension Home {
    class ViewController: UIHostingController<ContentView> {
        
        let profileAction: () -> Void
        let myOrdersAction: () -> Void
        let settingsAction: () -> Void
        
        init(profileAction: @escaping () -> Void,
             myOrdersAction: @escaping () -> Void,
             settingsAction: @escaping () -> Void) {
            self.profileAction = profileAction
            self.myOrdersAction = myOrdersAction
            self.settingsAction = settingsAction
            super.init(rootView: ContentView(viewModel: Home.ViewModel(
                profileAction: profileAction,
                myOrdersAction: myOrdersAction,
                settingsAction: settingsAction)))
            self.configureTabBarItem(selectedImage: UIImage(systemName: "safari.fill"))
            
        }
        
        @MainActor required dynamic init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
}

enum TabBarType: Int {
    case home
    case shoppingCart
    
    var title: String {
        switch self {
        case .home:
            return "Home"
        case .shoppingCart:
            return "Shopping Cart"
        }
    }
}
