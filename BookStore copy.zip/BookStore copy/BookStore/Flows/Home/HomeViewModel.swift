//
//  HomeViewModel.swift
//  BookStore
//
//  Created by George Predan on 10.02.2023.
//

import Foundation

extension Home {
    class ViewModel: ObservableObject {
        @Published var showSideBar = false
        let profileAction: () -> Void
        let myOrdersAction: () -> Void
        let settingsAction: () -> Void
        
        init(showSideBar: Bool = false,
             profileAction: @escaping () -> Void,
             myOrdersAction: @escaping () -> Void,
             settingsAction: @escaping () -> Void) {
            self.showSideBar = showSideBar
            self.profileAction = profileAction
            self.myOrdersAction = myOrdersAction
            self.settingsAction = settingsAction
        }
    }
}
