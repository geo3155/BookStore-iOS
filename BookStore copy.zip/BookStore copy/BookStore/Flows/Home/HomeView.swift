//
//  HomeView.swift
//  BookStore
//
//  Created by George Predan on 28.11.2022.
//

import SwiftUI

struct Home {
    struct ContentView: View {
        @StateObject var viewModel: ViewModel
        var body: some View {
            SideBarStack(sideBarContent: {
                SideBarView(
                    profileAction: viewModel.profileAction,
                    myOrdersAction: viewModel.myOrdersAction,
                    settingsAction: viewModel.settingsAction)
            }, mainContent: {
                homeContent
            }, showSideBar: $viewModel.showSideBar)
        }
        
        private var homeContent: some View {
            VStack(spacing: 32) {
                header
                VStack {
                    Text("What order would you like to order")
                        .font(.Main.bold(size: 30))
                }
            }
            .padding(.horizontal)
        }
        
        private var header: some View {
            HStack {
                MenuButton {
                    viewModel.showSideBar.toggle()
                }
                
                Spacer()
                
                ProfileIcon()
            }
            .padding(.horizontal)
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        Home.ContentView(viewModel: .init(profileAction: {
            
        }, myOrdersAction: {}, settingsAction: {}))
    }
}
