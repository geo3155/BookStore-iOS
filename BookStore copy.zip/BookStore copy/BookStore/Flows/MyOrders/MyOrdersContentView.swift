//
//  MyOrdersContentView.swift
//  BookStore
//
//  Created by George Predan on 26.02.2023.
//

import SwiftUI


struct MyOrders {
    struct ContentView: View {
        @StateObject var viewModel: ViewModel
        
        var body: some View {
            VStack {
                ScrollView {
                    VStack(spacing: 20) {
                        ForEach(viewModel.books, id: \.id) { book in
                            OrderItemView(book: book,
                                          orderStatus: .inProgress)
                        }
                    }
                    .padding(.horizontal)
                }
            }
            .viewTitleInLine(title: "My Orders", backButton: true) {
                viewModel.buttonAction()
            }
            .onAppear {
                viewModel.getData()
            }
        }
    }
}


struct MyOrdersContentView_Previews: PreviewProvider {
    static var previews: some View {
        MyOrders.ContentView(viewModel: MyOrders.ViewModel(buttonAction: {
            
        }))
    }
}
