//
//  MyOrdersViewController.swift
//  BookStore
//
//  Created by George Predan on 26.02.2023.
//

import Foundation
import SwiftUI
import UIKit

extension MyOrders {
    class ViewController: UIHostingController<ContentView> {
        let buttonAction: () -> Void
        
        init(buttonAction: @escaping () -> Void) {
            self.buttonAction = buttonAction
            super.init(rootView: MyOrders.ContentView(viewModel: MyOrders.ViewModel(buttonAction: self.buttonAction)))
        }
        
        @MainActor required dynamic init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
}
