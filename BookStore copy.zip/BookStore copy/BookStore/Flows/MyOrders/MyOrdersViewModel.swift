//
//  MyOrdersViewModel.swift
//  BookStore
//
//  Created by George Predan on 26.02.2023.
//

import Foundation
import FirebaseFirestore


extension MyOrders {
    class ViewModel: ObservableObject {
        
        @Published var books: [BookFireStore] = []
        
        init(buttonAction: @escaping () -> Void) {
            self.buttonAction = buttonAction
        }
        
        let buttonAction: () -> Void
        
        func getData() {
            
            let db = Firestore.firestore()
            
            db.collection("books").getDocuments { [weak self] snapshot, error in
                if let error = error {
                    print(error.localizedDescription)
                    return
                }
                guard let snapshot = snapshot else { return }
                
                let storedBooks = snapshot.documents.compactMap { BookFireStore(queryDocument: $0) }
                
                DispatchQueue.main.async {
                    self?.books = storedBooks
                }
            }
        }
        
        //        func downloadFiles() {
        //            let storage = Storage.storage()
        //
        //            let storageRef = storage.reference()
        //        }
    }
}
