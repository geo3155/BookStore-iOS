//
//  SettingsViewController.swift
//  BookStore
//
//  Created by George Predan on 09.02.2023.
//

import Foundation
import UIKit
import SwiftUI

extension Settings {
    class ViewController: UIHostingController<ContentView> {
        
        init() {
            super.init(rootView: ContentView())
            self.configureTabBarItem(selectedImage: UIImage(systemName: "gear"))
        }
        
        @MainActor required dynamic init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
}
