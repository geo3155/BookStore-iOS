//
//  RegisterViewController.swift
//  BookStore
//
//  Created by George Predan on 01.12.2022.
//

import Foundation
import SwiftUI
import UIKit

extension Register {
    class ViewController: UIHostingController<ContentView> {
        
        let onRegister: () -> Void
        let onBack: () -> Void
        
        init(onRegister: @escaping () -> Void, onBack: @escaping () -> Void) {
            self.onRegister = onRegister
            self.onBack = onBack
            super.init(rootView: ContentView(viewModel: ViewModel(onRegister: self.onRegister, onBack: self.onBack)))
        }
        
        @MainActor required dynamic init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
}
