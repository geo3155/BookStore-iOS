//
//  RegisterContentView.swift
//  BookStore
//
//  Created by George Predan on 01.12.2022.
//

import SwiftUI

struct Register {
    struct ContentView: View {
        
        @StateObject var viewModel: ViewModel
        
        var body: some View {
            ScrollView {
                VStack(spacing: 30) {
                    VStack(alignment: .leading, spacing: 30) {
                        
                        BackButton(action: viewModel.onBack)
                        
                        Spacer()
                        
                        Text("Sign Up")
                            .font(.Main.bold(size: 36))
                        
                        CustomTextField(text: $viewModel.fullName, name: "Full name")
                        
                        CustomTextField(text: $viewModel.email, name: "E-mail")
                        
                        CustomSecureField(text: $viewModel.password, name: "Password")
                    }
                    .padding(.horizontal)
                    LoginButton(title: "SIGN UP") {
                        viewModel.onRegister()
                        viewModel.saveUserData()
                    }
                    LoginBottom(bottomType: .register)
                }
                .padding(.vertical)
            }
        }
    }
}

struct RegisterContentView_Previews: PreviewProvider {
    static var previews: some View {
        Register.ContentView(viewModel: Register.ViewModel(onRegister: {}, onBack: {}))
    }
}
