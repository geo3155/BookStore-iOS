//
//  RegisterViewModel.swift
//  BookStore
//
//  Created by George Predan on 02.12.2022.
//

import Foundation

extension Register {
    class ViewModel: ObservableObject {
        @Published var fullName: String = ""
        @Published var email: String = ""
        @Published var password: String = ""
        
        let userRepository = UserRepository.shared
        
        let onRegister: () -> Void
        let onBack: () -> Void
        
        init(onRegister: @escaping () -> Void, onBack: @escaping () -> Void) {
            self.onRegister = onRegister
            self.onBack = onBack
        }
        
        func saveUserData() {
            userRepository.updateUser(fullName: fullName, email: email, password: password)
            
            Session.didInstallApp = true
        }
    }
}
