//
//  ProfileViewController.swift
//  BookStore
//
//  Created by George Predan on 10.02.2023.
//

import Foundation
import SwiftUI
import UIKit

extension ProfileSettings {
    class ViewController: UIHostingController<ContentView> {
        
        var backAction: () -> Void
        
        init(backAction: @escaping () -> Void) {
            self.backAction = backAction
            super.init(rootView: ContentView(viewModel: ProfileSettings.ViewModel(backAction: backAction)))
        }
        
        @MainActor required dynamic init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
}
