//
//  ProfileSettingsView.swift
//  BookStore
//
//  Created by George Predan on 10.02.2023.
//

import SwiftUI

struct ProfileSettings {
    struct ContentView: View {
        @StateObject var viewModel: ViewModel
        @StateObject private var userRepository = UserRepository.shared
        var body: some View {
            VStack(spacing: 40) {
                profileInfo
                VStack(spacing: 20) {
                    CustomTextField(text: $viewModel.fullName, name: "Full Name")
                    
                    CustomTextField(text: $viewModel.email, name: "Email")
                }
                .padding(.horizontal)
                
                LoginButton(title: "Save") {
                    viewModel.userRepository.updateUser(fullName: viewModel.fullName, email: viewModel.email, password: "")
                }
            }
            .frame(maxHeight: .infinity)
            .overlay(alignment: .topLeading) {
                BackButton {
                    viewModel.backAction()
                }
                .padding([.leading, .top])
            }
            .actionSheet(isPresented: $viewModel.isActionSheetShown) {
                actionSheet
            }
            .sheet(isPresented: $viewModel.isImagePickerPresented) {
                PhotoPicker(delegate: viewModel.self)
            }
            .sheet(isPresented: $viewModel.isCameraPresented) {
                ImagePicker(delegate: viewModel.self)
            }
            .alert(isPresented: $viewModel.isAlertPresented) {
                alert
            }
            
        }
        
        private var alert: Alert {
            Alert(title: Text("Allow camera"),
                  primaryButton: .cancel(),
                  secondaryButton: .default(Text("Settings"),
                  action: viewModel.toSetings))
        }
        
        private var actionSheet: ActionSheet {
            ActionSheet(title: Text("Choose an option"), buttons: [
                .default(Text("Take a photo"), action: {viewModel.checkPermissionCamera()}),
                .default(Text("Select from gallery"), action: {viewModel.isImagePickerPresented.toggle()}),
                .cancel({viewModel.isActionSheetShown = false })])
        }
        
        private var profileInfo: some View {
            VStack {
                profilePhoto
                Text(userRepository.user?.userName ?? "")
                    .font(.Main.regular(size: 20))
                Text("Edit profile")
                    .font(.Main.regular(size: 14))
                    .foregroundColor(.gray)
            }
        }
        private var profilePhoto: some View {
            Button {
                viewModel.isActionSheetShown = true
            } label: {
                ProfileIcon(size: CGSize(width: 90, height: 90))
                    .clipShape(Circle())
                    .overlay(alignment: .bottomTrailing) {
                        cameraIcon
                    }
            }
            .buttonStyle(.plain)
        }
        
        private var cameraIcon: some View {
            Circle()
                .fill(.white)
                .frame(width: 27, height: 27)
                .overlay {
                    Image(systemName: "camera.fill")
                        .resizable()
                        .scaledToFit()
                        .frame(height: 10)
                        .foregroundColor(.gray)
                }
        }
    }
}


struct ProfileSettingsView_Previews: PreviewProvider {
    static var previews: some View {
        ProfileSettings.ContentView(viewModel: ProfileSettings.ViewModel(backAction: {
            
        }))
    }
}
