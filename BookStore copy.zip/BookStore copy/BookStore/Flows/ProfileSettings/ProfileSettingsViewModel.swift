//
//  ProfileSettingsViewModel.swift
//  BookStore
//
//  Created by George Predan on 10.02.2023.
//

import Foundation
import SwiftUI
import AVFoundation

extension ProfileSettings {
    class ViewModel: ObservableObject {
        @Published var fullName: String
        @Published var email: String
        @Published var isActionSheetShown = false
        @Published var isCameraPresented = false
        @Published var isImagePickerPresented = false
        @Published var isAlertPresented = false
        @Published var selectedImage: Image?
        @Published var error: String?
        
        let userRepository = UserRepository.shared
        let backAction: () -> Void
        
        init(backAction: @escaping () -> Void) {
            self.backAction = backAction
            self.fullName = userRepository.user?.userName ?? ""
            self.email = userRepository.user?.email ?? ""
        }
        
        func checkPermissionCamera() {
            Task(priority: .userInitiated) { @MainActor in
                let isGranted = await AVCaptureDevice.requestAccess(for: .video)
                if isGranted {
                    isCameraPresented = true
                }
                else {
                    isAlertPresented = true
                }
            }
        }
        
        func toSetings() {
            guard let url = URL(string: UIApplication.openSettingsURLString), UIApplication.shared.canOpenURL(url) else {
                return
            }
            UIApplication.shared.open(url)
        }
    }
}

extension ProfileSettings.ViewModel: ImagePickerDelegate {
    
    func didReceiveImage(_ image: UIImage?) {
        guard let image = image else {
            return
        }
        self.selectedImage = Image(uiImage: image)
        Session.profilePhoto = selectedImage ?? Session.profilePhoto
    }
    
    func didReceiveError(_ error: Error?) {
        guard let error = error else {
            return
        }
        self.error = error.localizedDescription
    }
}
