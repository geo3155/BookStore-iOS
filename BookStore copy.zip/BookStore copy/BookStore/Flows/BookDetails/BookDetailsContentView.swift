//
//  BookDetails.swift
//  BookStore
//
//  Created by George Predan on 25.02.2023.
//

import SwiftUI

struct BookDetails {
    struct ContentView: View {
        let backButtonAction: () -> Void
        let book: Book
        var body: some View {
            VStack {
                ScrollView {
                    VStack(alignment: .leading) {
                        Image("FavoriteItem")
                            .resizable()
                            .frame(height: 206)
                            .clipShape(RoundedRectangle(cornerRadius: 10))
                            .overlay(alignment: .topTrailing) {
                                StarButton()
                                    .padding()
                            }
                        Text(book.name)
                            .font(.Main.regular(size: 28))
                        rating
                        priceQuantity
                        
                        Text(book.format.rawValue)
                            .font(.Main.regular(size: 18))
                            .foregroundColor(.gray)
                        
                    }
                    .padding(.horizontal)
                }
                    Spacer()
                
                LoginButton(title: "Add to cart") {
                    
                }
            }
            .viewTitleInLine(title: "", backButton: true) {
                backButtonAction()
            }
        }
        
        private var rating: some View {
            HStack(spacing: 4) {
                Image(systemName: "star.fill")
                    .foregroundColor(.yellow)
                Text("4.5")
                    .font(.Main.regular(size: 14))
                Text("(30+)")
                    .foregroundColor(.gray)
                    .font(.Main.regular(size: 14))
            }
        }
        
        private var priceQuantity: some View {
            HStack {
                Text("\(book.price.description) RON")
                    .foregroundColor(.neonBlue)
                    .font(.Main.regular(size: 31))
                Spacer()
                QuantityHandlerView()
            }
        }
    }
}

struct BookItem_Previews: PreviewProvider {
    static var previews: some View {
        BookDetails.ContentView(backButtonAction: {}, book: Book(name: "Swift Documentation", format: .hardCover, image: Image(""), price: 72.9))
    }
}
