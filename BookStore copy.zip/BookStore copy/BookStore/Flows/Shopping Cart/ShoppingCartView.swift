//
//  ShoppingCartView.swift
//  BookStore
//
//  Created by George Predan on 09.02.2023.
//

import SwiftUI
import Foundation

struct ShoppingCart {
    struct ContentView: View {
        var body: some View {
            VStack {
                ScrollView {
                    VStack(spacing: 25) {
                        
                        ShoppingCartItem(book: Book(name: "Carte", format: .audioBook, image: Image("ProfilePhoto"), price: 25.55))
                        ShoppingCartItem(book: Book(name: "Carte", format: .audioBook, image: Image("ProfilePhoto"), price: 25.55))
                        
                        PromoCodeView()
                        
                        VStack {
                            priceDetail(text: "Subtotal", price: 100)
                            Divider()
                            priceDetail(text: "Tax and Fees", price: 6)
                            Divider()
                            priceDetail(text: "Total", price: 106)
                        }
                        
                        Spacer()
                        
                        
                    }
                }
                .viewTitleInLine(title: "Cart")
                LoginButton(title: "Checkout") {
                    
                }
                .padding(.bottom)
            }
        }
        
        private func priceDetail(text: String, price: Int) -> some View {
            HStack {
                Text(text)
                    .font(.Main.regular(size: 20))
                Spacer()
                Text("\(price) RON")
                    .font(.Main.medium(size: 23))
            }
            .padding(.horizontal)
        }
    }
}

struct ShoppingCartView_Previews: PreviewProvider {
    static var previews: some View {
        ShoppingCart.ContentView()
    }
}

extension View {
    func viewTitleInLine(title: String,
                         size: CGFloat = 20,
                         color: Color = .black,
                         backButton: Bool = false,
                         buttonAction: (() -> Void)? = nil) -> some View {
        
        @ViewBuilder
        var button: some View {
            if backButton {
                HStack {
                    BackButton(action: {
                        buttonAction?()
                    })
                    Spacer()
                }
                    .padding(.leading)
            }
        }
        
        return VStack(spacing: 20) {
            Text(title)
                .font(.Main.medium(size: size))
                .foregroundColor(.black)
                .frame(maxWidth: .infinity)
                .overlay {
                    button
                }
            self
        }
    }
}

enum NavigationBarType {
    case inLineTitle
    case backNavigation
}
