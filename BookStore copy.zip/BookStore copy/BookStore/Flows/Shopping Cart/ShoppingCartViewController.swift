//
//  ShoppingCartViewController.swift
//  BookStore
//
//  Created by George Predan on 09.02.2023.
//

import Foundation
import UIKit
import SwiftUI

extension ShoppingCart {
    class ViewController: UIHostingController<ContentView> {
        
        init() {
            super.init(rootView: ContentView())
            self.configureTabBarItem(selectedImage: UIImage(systemName: "bag.fill"))
        }
        
        @MainActor required dynamic init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
}
