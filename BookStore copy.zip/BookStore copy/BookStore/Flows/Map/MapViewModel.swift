//
//  MapViewModel.swift
//  BookStore
//
//  Created by George Predan on 16.02.2023.
//

import MapKit

extension MapView {
    class ViewModel: ObservableObject {
        @Published var localityName: String = "Allow location"
        @Published var showPermissionAlert = false
        
        let libraries: [Library] = [.init(coordinates: CLLocationCoordinate2D(latitude: 46.768854992061456, longitude: 23.59037180700895)), .init(coordinates: CLLocationCoordinate2D(latitude: 44.438025, longitude: 26.105654))]
        
        private let locationManager = LocationManager.shared
        private let geocoder = CLGeocoder()
        
        init() {
            getLocationName()
        }
        
        func getLocationName() {
            guard let location = locationManager.currentLocation else {
                return
            }
            geocoder.reverseGeocodeLocation(location) { placemarks, error in
                guard let placemark = placemarks?.first else {
                    return
                }
                DispatchQueue.main.async {
                    self.localityName = placemark.locality ?? "Unknown location"
                }
            }
        }
        
        func manageUserLocation() {
            guard locationManager.locationEnabled else {
                showPermissionAlert = true
                return
            }
            DispatchQueue.main.async {
                self.locationManager.centerViewOnUser()
            }
        }
        
        func toSettings() {
            guard let url = URL(string: UIApplication.openSettingsURLString) else { return }
            guard UIApplication.shared.canOpenURL(url) else {
                return
            }
            UIApplication.shared.open(url)
        }
    }
}
