//
//  LocationManager.swift
//  BookStore
//
//  Created by George Predan on 16.02.2023.
//

import MapKit

class LocationManager: NSObject, ObservableObject {
    
    static let shared: LocationManager = .init()
    
    @Published private(set) var locationEnabled: Bool = true
    @Published var currentRegion: MKCoordinateRegion = .defaultRegion
    
    let locationManager = CLLocationManager()
    
    var currentLocation: CLLocation? {
        locationManager.location
    }
    
    private override init() {
        super.init()
        checkForLocationService()
    }
    
    func checkForLocationService() {
        guard [CLAuthorizationStatus.authorizedAlways, .authorizedWhenInUse].contains(locationManager.authorizationStatus) else {
            checkLocationAuthorization()
            return
        }
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyThreeKilometers
    }
    
    func checkLocationAuthorization() {
        DispatchQueue.main.async { [self] in
            switch locationManager.authorizationStatus {
            case .notDetermined:
                locationManager.requestWhenInUseAuthorization()
            case .restricted, .denied:
                locationEnabled = false
            case .authorizedAlways, .authorizedWhenInUse:
                locationManager.startUpdatingLocation()
            @unknown default:
                break
            }
        }
    }
    
    func centerViewOnUser() {
        guard let location = currentLocation else {
            return
        }
        self.currentRegion = MKCoordinateRegion(center: location.coordinate,
                                                span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05))
    }
}

extension LocationManager: CLLocationManagerDelegate {
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let _ = locations.last else {
            return
        }
        DispatchQueue.main.async { [self] in
            locationManager.startUpdatingLocation()
        }
    }
    
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        DispatchQueue.main.async { [self] in
            checkLocationAuthorization()
        }
    }
}

extension MKCoordinateRegion {
    static let defaultRegion = MKCoordinateRegion(center: .init(latitude: 44.4380170, longitude: 26.1056134),
                                                  span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05))
}
