//
//  MapView.swift
//  BookStore
//
//  Created by George Predan on 09.02.2023.
//

import SwiftUI
import MapKit

struct MapView {
    struct ContentView: View {
        
        @StateObject var viewModel = ViewModel()
        @StateObject var locationManager = LocationManager.shared
        var body: some View {
            map
                .ignoresSafeArea(.container, edges: .top)
                .alert(isPresented: $viewModel.showPermissionAlert) {
                    alert
                }
        }
        private var map: some View {
            Map(coordinateRegion: $locationManager.currentRegion,
                interactionModes: .all,
                showsUserLocation: true,
                annotationItems: viewModel.libraries,
                annotationContent: { library in
                MapAnnotation(coordinate: library.coordinates) {
                    libraryAnnotation
                }
            })
            .overlay(alignment: .bottomTrailing, content: {
                LocationButton(action: locationManager.centerViewOnUser)
                    .padding()
            })
            .accentColor(.neonBlue)
            .onAppear {
                viewModel.manageUserLocation()
            }
        }
        
        private var alert: Alert {
            Alert(title: Text("Allow location"),
                  primaryButton: .cancel(),
                  secondaryButton: .default(Text("Settings"), action: viewModel.toSettings))
        }
        
        private var libraryAnnotation: some View {
            Image(systemName: "books.vertical.fill")
                .resizable()
                .frame(height: 30)
                .foregroundColor(.maxBluePurple)
        }
    }
    
    
}

struct MapView_Previews: PreviewProvider {
    static var previews: some View {
        MapView.ContentView()
    }
}
