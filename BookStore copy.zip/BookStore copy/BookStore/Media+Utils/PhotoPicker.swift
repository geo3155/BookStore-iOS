//
//  PhotoPicker.swift
//  BookStore
//
//  Created by George Predan on 11.02.2023.
//

import Foundation
import SwiftUI
import UIKit
import PhotosUI

protocol ImagePickerDelegate {
    func didReceiveImage(_ image: UIImage?)
    func didReceiveError(_ error: Error?)
}

struct PhotoPicker: UIViewControllerRepresentable {
    
    var delegate: ImagePickerDelegate
    
    func makeUIViewController(context: Context) -> PHPickerViewController {
        var configuration: PHPickerConfiguration = .init(photoLibrary: .shared())
        configuration.selectionLimit = 1
        configuration.filter = .images
        let pickerVC = PHPickerViewController(configuration: configuration)
        pickerVC.delegate = context.coordinator
        return pickerVC
    }
    
    func updateUIViewController(_ uiViewController: UIViewControllerType, context: Context) {
        
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(delegate: delegate)
    }
    
    class Coordinator: PHPickerViewControllerDelegate {
        
        var delegate: ImagePickerDelegate
        
        init(delegate: ImagePickerDelegate) {
            self.delegate = delegate
        }
        
        func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
            
            picker.dismiss(animated: true, completion: nil)
            
            guard let result = results.first else {
                return
            }
            
            guard result.itemProvider.canLoadObject(ofClass: UIImage.self) else {
                return
            }
            
            result.itemProvider.loadObject(ofClass: UIImage.self) { image, error in
                DispatchQueue.main.async {
                    guard error == nil else {
                        self.delegate.didReceiveError(error!)
                        return
                    }
                    self.delegate.didReceiveImage(image as? UIImage)
                }
            }
        }
    }
}




