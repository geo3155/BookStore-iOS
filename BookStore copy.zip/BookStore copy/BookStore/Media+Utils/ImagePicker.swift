//
//  ImagePicker.swift
//  BookStore
//
//  Created by George Predan on 12.02.2023.
//

import Foundation
import UIKit
import SwiftUI
import AVFoundation

struct ImagePicker: UIViewControllerRepresentable {

    var delegate: ImagePickerDelegate

    func makeUIViewController(context: Context) -> UIImagePickerController {
        let imagePicker = UIImagePickerController()
        imagePicker.sourceType = .camera
        imagePicker.cameraCaptureMode = .photo
        imagePicker.cameraFlashMode = .off
        imagePicker.showsCameraControls = true
        imagePicker.delegate = context.coordinator
        return imagePicker
    }

    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {

    }

    func makeCoordinator() -> Coordinator {
        Coordinator(delegate: delegate)
    }

    class Coordinator: NSObject, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
        var delegate: ImagePickerDelegate

        init(delegate: ImagePickerDelegate) {
            self.delegate = delegate
        }

        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            guard let image = info[.originalImage] else {
                return
            }
            delegate.didReceiveImage(image as? UIImage)
            picker.dismiss(animated: true)
        }
        
        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            picker.dismiss(animated: true)
        }
    }
}
